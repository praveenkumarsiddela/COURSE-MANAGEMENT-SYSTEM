const express = require('express')
//
const app = express()
//

app.get('/', function (req, res) {
  res.send('Hello World')
})

app.get('/ift458', function (req, res) {
  res.send('Hello IFT458')
})

app.listen(3000)

// to start the server, always run in debug mode