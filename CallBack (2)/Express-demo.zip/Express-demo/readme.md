https://dailyspaghetticode.com/adding-swagger-to-your-expressjs-api/#:~:text=Adding%20Swagger%20to%20your%20ExpressJS%20API%201%20Installing,Check%20it%20out%20Finally%21%20...%205%20Conclusion%20
