const express = require("express");
//
const app = express();
const PORT = 4000;
//

//create middleware to add a timestamp to the request
app.use((req, res, next) => {
  console.log("Time: ", Date.now());
  next();
});


app.get("/", (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=pe">
    <title>Document</title>
</head>
<body>
    <p>hello world from html</p>
</body>
</html>`);

  res.send(JSON.stringify(req.baseUrl));
});

app.get("/ift458", (req, res) => {
  res.send("Hello IFT458");
});

app.get("/customerdata", (req, res) => {
  res.send(`
  <!DOCTYPE html>
<html>
<head>
    <title>Ask for Info</title>
</head>
<body>
    <h1>Enter Your Information</h1>
    <form action="/formdata" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="number">Number:</label>
        <input type="tel" id="number" name="number" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>

`);

});

// app.post("/formdata", (req, res) => {
//   console.log(req.body);
// });


app.listen(PORT, () => {
  console.log(`Server is running at port ${PORT}`);
});

// to start the server, always run in debug mode
