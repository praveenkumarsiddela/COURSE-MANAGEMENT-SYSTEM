const express = require("express");
const bodyParser = require("body-parser");

//
const app = express();
const PORT = 4000;
//

//create middleware to add a timestamp to the request
// app.use((req, res, next) => {
//   console.log("Time: ", Date.now());
//   next();
// });

// use middle ware to parse the body of the request
app.use(bodyParser.urlencoded({ extended: false }));  
app.use(bodyParser.json());

// router maps
app.get("/", async (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=pe">
    <title>Document</title>
</head>
<body>
    <p>hello world from html</p>
</body>
</html>`);

  res.send(JSON.stringify(req.baseUrl));
});

app.get("/ift458", (req, res) => {
  res.send("Hello IFT458");
});

app.get("/customerdata", (req, res) => {
  res.send(`
  <!DOCTYPE html>
<html>
<head>
    <title>Ask for Info</title>
</head>
<body>
    <h1>Enter Your Information</h1>
    <form action="/formdata" method="POST">
        <label for="fistName">Firt Name:</label>
        <input type="text" id="fistName" name="fistName" required><br><br>
        
        <label for="lastName">Last Name:</label>
        <input type="tel" id="lastName" name="lastName" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>

`);

});

app.post("/formdata", async (req, res) => {
  const data = await req.body;
  console.log(req.body);
});


app.listen(PORT, () => {
  console.log(`Server is running at port ${PORT}`);
});

// to start the server, always run in debug mode
